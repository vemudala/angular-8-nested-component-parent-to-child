export interface ITile {  // create interface by "ng generate interface ITile" next add variables and types
    image:string;
    name:string;
    model:string;
    price:number;
    rating:number;
    status:number;

}
